export const defaultNodeConfig = {
  autoRestart: true,
};

export type nodeConfigType = typeof defaultNodeConfig;
