export const defaultGuiConfig = {
  gui: {
    port: 8080,
    pass: '',
  },
};
